---
name: proxmox-resource-reporting
description: Generate detailed resource reports from Proxmox VE cluster including node status, VMs, LXC containers, and storage utilization
category: devops
---

# Proxmox Resource Reporting Skill

## When to Use
Use this skill when you need to generate detailed resource reports from a Proxmox VE cluster, including node status, VMs, LXC containers, and storage utilization. Particularly useful for monitoring homelab or production Proxmox environments.

## Prerequisites
- Access to Proxmox VE API (typically port 8006)
- Valid API token with appropriate permissions
- Python 3.x with urllib and json modules
- ~/.proxmox-credentials file with:
  - PROXMOX_HOST=https://your-proxmox-host:8006
  - PROXMOX_TOKEN_ID=your-token-id@pam!your-token-name
  - PROXMOX_TOKEN_SECRET=your-token-secret
  - AGENTMAIL_API_KEY=your-agentmail-key (for email delivery)

## Approach
Proxmox API token authentication uses a non-standard format: `PVEAPIToken=TOKEN_ID=TOKEN_SECRET` (note the double equals, not colon). This is a common point of failure.

## Steps

### 1. Verify Credentials Format
Check your ~/.proxmox-credentials file:
```bash
cat ~/.proxmox-credentials
```
Should contain:
```
export PROXMOX_HOST=https://host:8006
export PROXMOX_TOKEN_ID=api-rw@pam!token-name
export PROXMOX_TOKEN_SECRET=your-secret-uuid
export AGENTMAIL_API_KEY=your-agentmail-key
```

### 2. Test API Connectivity
Use this Python snippet to verify token format:
```python
import os
import urllib.request
import json
import ssl

# Load credentials
with open(os.path.expanduser('~/.proxmox-credentials'), 'r') as f:
    for line in f:
        if line.strip() and not line.startswith('#'):
            if 'export' in line:
                line = line.strip()
                if line.startswith('export '):
                    line = line[7:]
                key, value = line.split('=', 1)
                os.environ[key] = value.strip('"')

host = os.environ["PROXMOX_HOST"]
token_id = os.environ["PROXMOX_TOKEN_ID"]
token_secret = os.environ["PROXMOX_TOKEN_SECRET"]
auth = f"PVEAPIToken={token_id}={token_secret}"  # NOTE: Double equals

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def api_call(endpoint):
    url = f"{host}/api2/json{endpoint}"
    req = urllib.request.Request(url, headers={"Authorization": auth})
    with urllib.request.urlopen(req, context=ctx) as response:
        return json.loads(response.read())["data"]

# Test with version endpoint (usually works)
try:
    version = api_call("/version")
    print(f"Proxmox Version: {version}")
except Exception as e:
    print(f"Auth failed: {e}")
```

### 3. Generate Resource Report
Use the working script approach:
1. Fetch node status: `/nodes/pve/status`
2. Fetch VMs: `/nodes/pve/qemu`
3. Fetch LXC containers: `/nodes/pve/lxc`
4. Fetch storage: `/nodes/pve/storage`
5. Format output with clear sections and warnings

### 4. Key Warnings to Watch For
- Storage pools >80% usage
- VMs with sustained high CPU usage (>80%)
- Memory usage >85% on node
- Any stopped critical services
- Backup storage status
- **Container disk over-allocation**: LXC root disk showing >100% usage (e.g., 8.37/4GB = 209%). This means the container is using more disk than its allocated size — investigate bind-mounts, filesystem quotas, or potential reporting bugs. Not always a real issue (bind mounts can inflate the number), but worth verifying.

### 5. Email Delivery
Reports can be sent via AgentMail API using the AGENTMAIL_API_KEY from credentials.

## Common Pitfalls
1. **Token Format**: Using `PVEAPIToken=ID:SECRET` instead of `PVEAPIToken=ID=SECRET`
2. **SSL Verification**: Self-signed certs require disabling verification
3. **Endpoint Paths**: Always use `/api2/json/` prefix
4. **Response Format**: Data is in `["data"]` field of JSON response
5. **Numeric Comparisons**: Load averages may be strings, not floats

## Verification
After generating report, verify:
- All expected VMs/containers are listed with correct status
- Storage percentages look reasonable
- Timestamp is current
- No authentication errors in output

## Example Output Format
```
============================================================
PROXMOX NODE RESOURCE REPORT
============================================================
Timestamp: 2026-03-31 07:46:37

- NODE OVERVIEW -
[Node details]

- VMs (QEMU) -
[VM table]

- LXC Containers -
[Container table]

- STORAGE -
[Storage table]

============================================================
Report complete.
============================================================
```

## Maintenance
- Update scripts if Proxmox API changes
- Monitor for authentication token expiration
- Adjust warning thresholds based on your environment