---
name: hermes-self-evolution-gepa
description: >
  Run GEPA (Genetic Evolution of Prompt Artifacts) skill optimization cycles on Hermes skills.
  Use when asked to improve skills, run self-evolution, optimize prompts, or audit skill quality.
  The pipeline lives at ~/hermes-agent-self-evolution. DSPy 3.1.3 is installed in its .venv.
version: 1.2.0
metadata:
  hermes:
    tags: [self-evolution, GEPA, DSPy, skills, optimization]
    trigger_conditions:
      - "Run a GEPA / self-evolution cycle"
      - "Optimize skills / audit skill quality"
      - "Improve skill reliability"
---

# Hermes Self-Evolution — GEPA Pipeline

## Environment

- **Repo:** `~/hermes-agent-self-evolution` (NousResearch/hermes-agent-self-evolution on GitHub)
- **Venv:** `/home/wahid/hermes-agent-self-evolution/.venv/bin/python`
- **DSPy version:** 3.1.3 (confirmed installed)
- **Skills source:** `~/.hermes/hermes-agent/` (NousResearch/hermes-agent)
- **Remote:** `https://github.com/NousResearch/hermes-agent-self-evolution.git`

## CLI Usage

```bash
# Dry run — validate setup without API calls
cd ~/hermes-agent-self-evolution && \
/home/wahid/hermes-agent-self-evolution/.venv/bin/python -m evolution.skills.evolve_skill \
  --skill <skill-name> \
  --dry-run

# Full optimization run
/home/wahid/hermes-agent-self-evolution/.venv/bin/python -m evolution.skills.evolve_skill \
  --skill github-pr-workflow \
  --iterations 5 \
  --optimizer-model anthropic/claude-haiku-3-5 \
  --eval-model anthropic/claude-haiku-3-5 \
  --eval-source synthetic
```

**CLI options:**
- `--skill` — skill name (short form, e.g. `github-pr-workflow` — matched by `find_skill()`)
- `--iterations` — GEPA iterations (default: 10; use 5 for fast cycles)
- `--eval-source` — `synthetic` | `golden` | `sessiondb`
- `--optimizer-model` / `--eval-model` — litellm model string
- `--run-tests` — gate on pytest suite (slow, opt-in)
- `--dry-run` — validate without API calls

## Step-by-Step Optimization Cycle

1. **Select targets** — pick 5 skills by word count + trigger frequency; highest delta potential = missing Pitfalls sections + vague descriptions
2. **Check API key** — if masked, use LLM-as-Judge fallback (Strategy A: direct parent execution)
3. **Run optimization** — for each skill: read, score baseline, write evolved SKILL.md to live path
4. **Sync to repo** — `cp` evolved files from `~/.hermes/skills/` to `~/.hermes/hermes-agent/skills/`. If the target directory doesn't exist in the repo, create it with `mkdir -p` first. If the file is new (didn't exist in the repo), it will appear as an untracked file — stage it with `git add` before generating patches.
5. **Generate patches** — `git diff` in hermes-agent repo
6. **Write report + metrics** — in `~/hermes-agent-self-evolution/reports/`
7. **Commit both repos** — skill changes in hermes-agent, patches+report in self-evolution
8. **Attempt push** — try `git push` to self-evolution repo; if 403, log branch name in report

## GEPA Scoring Dimensions (0–10 each)

| Dimension | What it measures |
|-----------|----------------|
| `trigger_clarity` | How precisely the `description:` field disambiguates from sibling skills |
| `step_completeness` | Steps numbered, actionable, with exact copy-pasteable commands |
| `pitfall_coverage` | Common failure modes documented |
| `command_accuracy` | Shell commands correct and runnable |
| `reuse_potential` | Generalizes well, no hardcoded personal paths |

## Fallback: LLM-as-Judge (when API unavailable)

When live GEPA fails (API key not accessible), use one of two fallback strategies:

### Strategy A: Direct Parent Execution (PREFERRED)

For 5 skills, the most reliable approach is to write evolved content directly in the parent session:
1. Read each source SKILL.md
2. Score 5 dimensions (0–10)
3. Write evolved SKILL.md with trigger_conditions, When to Use, Not For, and Pitfalls
4. Sync to both paths, generate patches, commit

This avoids subagent timeout risk entirely and is faster for batches of ≤5 skills.

### Strategy B: Subagent Delegation (use only if parent context is full)

If the parent session context is too large to hold all skill content, delegate to subagents in parallel batches:

- **≤3 skills:** single subagent
- **4–5 skills:** split into 2 parallel tasks (e.g. 3+2) using `delegate_task(tasks=[...])`
- **6+ skills:** 3 parallel tasks of ~2 each

⚠️ **Subagent timeout risk:** Subagents may time out at 600s when asked to read + score + write evolved content for 2+ large skills. If 2 of 3 subagents time out (as observed in cycle 5), fall back to Strategy A for the remaining skills.

Each subagent prompt must:
1. Score 5 dimensions (0–10): `trigger_clarity`, `step_completeness`, `pitfall_coverage`, `command_accuracy`, `reuse_potential`
2. Write a fully evolved SKILL.md with Pitfalls section (5–7 failure modes), trigger_conditions in YAML, When to Use / Not For
3. **Write evolved content directly to the target SKILL.md path** — do NOT write to intermediate JSON files in arbitrary directories
4. Return **JSON only** (parseable) — no markdown wrapper, no preamble

```
goal: "Perform GEPA-style LLM-as-Judge scoring on skills X, Y, Z.
Read full SKILL.md for each from these paths: ...
Score 5 dimensions 0-10. Write fully optimized versions with Pitfalls.
Write evolved SKILL.md directly to the target path for each skill.
Output format: JSON {skill_name: {baseline_scores, evolved_scores, changes_summary}}
IMPORTANT: Output ONLY the JSON. No preamble, No markdown wrapper."
toolsets: ["terminal", "file"]
```

After subagents return (or time out), apply any missing evolved content directly, then sync and commit.

## GitHub Auth (Push to NousResearch)

⚠️ **Known blocker as of 2026-04-10:** All 3 available accounts lack push access:
- `friday-openclaw[bot]` — token invalid (gh auth shows failed)
- `jarvis4openclaw` — 403 on NousResearch org
- `wahidsaleemi` — 403 on NousResearch org

**Fix needed:** Grant push access to one of the above accounts. Until then, commit locally and report the branch name.

```bash
# Switch accounts
gh auth switch --user jarvis4openclaw
gh auth token  # verify

# Push once access is granted
cd ~/hermes-agent-self-evolution
GH_TOKEN=$(gh auth token) git push -u origin <branch>

# Create PR
gh pr create --title "feat: GEPA cycle N — skill optimization" \
  --body "..." --base main
```

## API Key Pitfall in Cron

`~/.hermes/.env` API keys may be **masked** (credential-manager-backed). Diagnose:
```bash
python3 -c "
with open('/home/wahid/.hermes/.env') as f:
    for l in f:
        if 'ANTHROPIC_API_KEY' in l:
            val = l.split('=',1)[1].strip()
            print(f'len={len(val)}, masked={\"***\" in val or len(val) < 20}')
"
```

If masked: store a plaintext service key in `~/.hermes/evolution-creds.env` and source it before running.

## Output Locations

- **Reports:** `~/hermes-agent-self-evolution/reports/gepa_cycle_N_report.md`
- **Metrics JSON:** `~/hermes-agent-self-evolution/reports/gepa_cycle_N_metrics.json`
- **Datasets:** `~/hermes-agent-self-evolution/datasets/skills/<skill-name>/`
- **Autonomy gaps:** `~/autonomy-gaps.md`

## When to Emit [SILENT]

The self-evolution cron cycle should emit `[SILENT]` (suppress delivery) when **all** of the following are true:

1. **No new session errors** — keyword search for `error failure retry` returns no sessions from the last 24h with undiagnosed issues.
2. **All active skills are current** — skills with "do NOT re-update" or "Adoption Status: awaiting manual action" markers are at their documented version; no version drift.
3. **No user correction in recent sessions** — keyword search for `user correction preference mistake wrong` returns no results.
4. **No new recurring pattern** — the same failure mode hasn't appeared in 2+ sessions since the last evolution that addressed it.

If any condition fails, produce a focused report on that one item. If all pass, emit `[SILENT]` — do not invent an improvement just to have output.

**Anti-pattern to avoid:** Producing a minor report ("No safe improvement found — top blocker: X") when X has been documented for a week and requires only manual operator action. That's noise, not signal. Emit `[SILENT]` instead.

## Manual LLM-as-Judge Cycle (No CLI)

When writing evolved skill content directly (without the CLI pipeline), the repo convention is:

1. **Write evolved SKILL.md** directly to `~/.hermes/skills/<category>/<skill>/SKILL.md` (the live path)
2. **Sync to repo path:** `cp ~/.hermes/skills/<path>/SKILL.md ~/.hermes/hermes-agent/skills/<path>/SKILL.md`. If the target directory doesn't exist in the repo, create it with `mkdir -p` first.
3. **Generate patch files** from the hermes-agent repo: `cd ~/.hermes/hermes-agent && git diff HEAD -- skills/<path>/SKILL.md > ~/hermes-agent-self-evolution/patches/<skill>/gepa-cycle-N.patch`. For new files (not in repo), use `git diff --no-index /dev/null skills/<path>/SKILL.md` or stage with `git add` first.
4. **Create mkdir** for each `patches/<skill>/` dir before writing
5. **Write report** to `~/hermes-agent-self-evolution/reports/gepa_cycle_N_report.md`
6. **Write metrics** to `~/hermes-agent-self-evolution/reports/gepa_cycle_N_metrics.json`
7. **Commit all** (patches + report + metrics) in the self-evolution repo
8. **Commit skill changes** in the hermes-agent repo

The self-evolution repo does NOT track skill files directly — only diffs (patches) and reports. The live skill changes happen in `~/.hermes/skills/` which is the path the running agent actually reads from.

## Pitfalls

1. **API key not plaintext in cron** — see section above. Live GEPA needs plaintext key. Fallback to LLM-as-Judge subagent.
2. **Skill name matching** — use the short skill name (e.g. `github-pr-workflow`), not the full path. `find_skill()` searches recursively under `~/.hermes/hermes-agent/skills/`.
3. **`--no-run-tests` doesn't exist** — the flag is `--run-tests` (boolean flag, default off). Don't pass `--no-run-tests`.
4. **Two separate skills directories** — `~/.hermes/hermes-agent/skills/` and `~/.hermes/skills/` have **different inodes** (confirmed cycle 3, 2026-04-12). They are NOT symlinked. The running agent reads from `~/.hermes/skills/` (live path). Always write evolved SKILL.md to the live path first, then sync to the repo path for version control. Pattern:
   ```bash
   # Write to live path first
   write_file(~/.hermes/skills/<path>/SKILL.md, evolved_content)
   # Then sync to repo
   cp ~/.hermes/skills/<path>/SKILL.md ~/.hermes/hermes-agent/skills/<path>/SKILL.md
   ```
5. **NousResearch org push access** — no currently valid account has push rights. Commit locally and surface to Boss with branch name.
6. **Subagent timeout on large content** — Subagents tasked with reading + scoring + writing evolved SKILL.md for 2+ large skills may time out at 600s. If subagents time out, complete the work directly in the parent session. See "Fallback: LLM-as-Judge" section for Strategy A (preferred) vs Strategy B.
7. **Patch generation ordering** — Patches must be generated AFTER syncing evolved content to the repo path. If patches are generated before syncing, they will be empty (0 lines). Always: write live → sync to repo → `git diff` → generate patch.
8. **Stale branch in self-evolution repo** — The self-evolution repo may be checked out to a branch from a previous cycle (e.g. `gepa/phase1-skill-optimization-cycle-3`). Commits made while on the wrong branch will NOT be on the intended cycle-N branch. Always run `git checkout main && git checkout -b gepa/phase1-skill-optimization-cycle-N` BEFORE committing. If you already committed to the wrong branch, use `git cherry-pick` to move the commit to the correct branch.
9. **Skill exists in live path but not in repo path** — Some skills in `~/.hermes/skills/` may not have a corresponding file in `~/.hermes/hermes-agent/skills/`. Before running `cp` to sync, check if the repo target path exists. If the parent directory doesn't exist, create it with `mkdir -p` first. If the file doesn't exist at all in the repo, it will show as a new file in `git diff` — stage it with `git add` before committing. Check with: `test -f ~/.hermes/hermes-agent/skills/<path>/SKILL.md || echo "NEW_FILE"`.
