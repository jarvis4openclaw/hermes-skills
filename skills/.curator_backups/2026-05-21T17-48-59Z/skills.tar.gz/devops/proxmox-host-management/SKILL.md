---
name: proxmox-host-management
description: Manage Proxmox VE host via SSH — cron jobs, systemd services, packages, config files, VM/CT operations, storage, network, and maintenance. Use when asked to inspect, fix, or change anything on the Proxmox host itself (not VMs/containers).
category: devops
---

# Proxmox Host Management Skill

## When to Use
Use this skill for any SSH-based management of the Proxmox VE host itself:
- Editing cron jobs, systemd services, config files
- Package updates, kernel management
- VM/CT lifecycle (start/stop/restart/snapshot via `qm`/`pct`)
- Storage pool management, backup scheduling
- Network config, firewall rules
- Log investigation, troubleshooting
- Maintenance tasks (log rotation, temp cleanup, etc.)

**Do NOT use for:** Read-only resource reports → use `proxmox-resource-reporting` skill instead.

## Access

- **Host:** `root@192.168.100.23` (pve)
- **SSH Key:** `/home/wahid/.ssh/id_ed25519`
- **SSH Command pattern:**
  ```bash
  ssh -i /home/wahid/.ssh/id_ed25519 -o StrictHostKeyChecking=no root@192.168.100.23 '<command>'
  ```
- **Proxmox version:** 9.1.0 (kernel 7.0.2-2-pve)

## Key Config Files

| File | Purpose |
|------|---------|
| `/etc/pve/user.cfg` | Proxmox user config (contains notification email) |

## Reference Files
- `references/ct200-root-disk-shrink.md` — Full shrink operation log (CT 200, 24G→20G)
| `/etc/pve/datacenter.cfg` | Datacenter-wide settings (contains notification email) |
| `/etc/cron.d/` | System cron jobs (e.g., `azcmagent_autoupgrade`) |
| `/etc/apt/sources.list.d/` | APT sources (Proxmox, Ceph, etc.) |
| `/etc/network/interfaces` | Network configuration |
| `/etc/hostname`, `/etc/hosts` | Hostname and hosts |
| `/etc/postfix/` or `/etc/ssmtp/` | Mail relay config |

## Notification Emails

Proxmox sends emails via **sSMTP relay through Gmail** (`smtp.gmail.com:587`).
Notification email addresses are set in BOTH:
- `/etc/pve/user.cfg`
- `/etc/pve/datacenter.cfg`

Current email: `onewahid@gmail.com` (changed from `onewahid@live.com` on 2026-02-14).

## Common Operations

### VM Management (`qm`)
```bash
# List all VMs
qm list

# Start/stop/restart
qm start <vmid>
qm stop <vmid>
qm restart <vmid>

# Snapshot
qm snapshot <vmid> <snapname> --description "..."

# Get config
qm config <vmid>

# Get status
qm status <vmid>
```

### LXC Container Management (`pct`)
```bash
# List all containers
pct list

# Start/stop/restart
pct start <ctid>
pct stop <ctid>
pct restart <ctid>

# Enter container shell
pct enter <ctid>

# Get config
pct config <ctid>
```

### LXC Container Root Disk Resizing

**Growing** (safe, can be done live on some setups, but stop CT for safety):
```bash
pct stop <ctid>
lvresize -L +<size>G /dev/pve/vm-<ctid>-disk-0
resize2fs /dev/pve/vm-<ctid>-disk-0
pct set <ctid> -rootfs local-lvm:vm-<ctid>-disk-0,size=<new-size>G
pct start <ctid>
```

**Shrinking** (requires CT stop + fs shrink BEFORE volume shrink):
```bash
pct stop <ctid>
e2fsck -fy /dev/pve/vm-<ctid>-disk-0       # MUST pass clean
resize2fs /dev/pve/vm-<ctid>-disk-0 <size>G  # filesystem FIRST
lvreduce -L <size>G /dev/pve/vm-<ctid>-disk-0 # volume SECOND
pct set <ctid> -rootfs local-lvm:vm-<ctid>-disk-0,size=<size>G
pct start <ctid>
pct exec <ctid> -- df -h /                     # verify
```

**Key pitfalls:**
- **Order matters for shrink:** You MUST shrink the filesystem before shrinking the LVM volume. Reversing this destroys data.
- **Stale config metadata:** Proxmox config `rootfs` size field can drift from actual LVM volume size (e.g., config says 4G but volume is 24G). Always check `lvs` and `df` for ground truth. Update with `pct set <ctid> -rootfs local-lvm:vm-<ctid>-disk-0,size=<size>G`.
- **Shrink requires clean fs:** `e2fsck -fy` must succeed before `resize2fs` will shrink. If it fails, do NOT proceed.
- **Enough headroom:** Target size must exceed used space (`df` shows used). Shrinking below used = data loss.

### Storage
```bash
# List storage
pvesm status

# List content of a storage
pvesm content <storage-name>

# Check specific storage details
pvesm path <storage-name>
```

### Systemd Services
```bash
# List all timers
systemctl list-timers --all

# Check a service
systemctl status <service>

# Restart a service
systemctl restart <service>

# Disable a timer
systemctl disable --now <timer>
```

### Cron Jobs
```bash
# List system cron jobs
ls -la /etc/cron.d/

# Edit a cron file (backup first!)
cp /etc/cron.d/<file> /etc/cron.d/<file>.bak
```

### Package Management
```bash
# Update package lists
apt update

# Upgrade (non-interactive)
DEBIAN_FRONTEND=noninteractive apt upgrade -y

# Check for proxmox updates specifically
pveupdate

# Check current version
pveversion -v
```

### Logs
```bash
# Proxmox daemon log
journalctl -u pvedaemon -n 100

# Cluster log
journalctl -u pve-cluster -n 100

# Task log (VM/CT operations)
cat /var/log/pve/tasks/active

# Syslog
tail -100 /var/log/syslog
```

### Network
```bash
# Show interfaces
ip addr show

# Show bridges
brctl show

# Show firewall
iptables -L -n

# Proxmox firewall config
cat /etc/pve/firewall/cluster.fw
```

## Known Pitfalls

### 1. Cron Emails
Cron sends **any output** (stdout OR stderr) via email to the job owner.
- `>/dev/null` only redirects **stdout** — stderr still gets emailed
- **Fix:** Use `>/dev/null 2>&1` (redirect stderr too)
- **Cleaner fix:** Add `MAILTO=""` at the top of the cron file to disable email entirely
- **Example:** `/etc/cron.d/azcmagent_autoupgrade` — Azure Arc update checker that was emailing daily

### 2. Azure Arc Agent (`azcmagent`)
- Installed at `/opt/azcmagent/`
- Cron job: `/etc/cron.d/azcmagent_autoupgrade` (daily 1:11 AM)
- Service: `azcmagent.service`
- Token storage: `/var/opt/azcmagent/tokens/`
- Can cause unwanted emails if cron output isn't fully silenced

### 3. Proxmox Config Files
- `/etc/pve/` is a virtual filesystem (pmxcfs) — changes are cluster-aware
- Editing files in `/etc/pve/` directly works but be careful with syntax
- Always backup before editing: `cp file file.bak`

### 4. SSH Escaping
- Complex commands with quotes need careful escaping
- For multi-line or complex edits, use heredoc pattern:
  ```bash
  ssh ... 'cat > /path/to/file << '"'"'EOF'"'"'
  content here
  EOF'
  ```
- Or use `sed -i` for simple replacements

### 5. Package Updates
- Don't run `apt dist-upgrade` on Proxmox without checking release notes
- Use `apt upgrade` for safe updates
- Kernel updates require reboot — schedule maintenance windows
- Check `pveupdate` for Proxmox-specific update info

### 6. Storage Reporting
- LXC container disk usage can show >100% due to bind-mounts inflating the number
- Not always a real issue, but worth verifying if unexpected

## Safety Rules

1. **Always backup before editing:** `cp file file.bak`
2. **Test after changes:** Verify the thing you changed actually works
3. **Don't reboot without asking** unless it's an emergency
4. **Don't run `apt dist-upgrade`** without Boss approval
5. **Don't modify `/etc/pve/` files** without understanding the syntax
6. **When in doubt, ask** — especially for network/firewall changes

## Verification Checklist

After making changes:
- [ ] Backup of original file exists
- [ ] Change is syntactically correct
- [ ] Service/timer/cron is in expected state
- [ ] No errors in logs
- [ ] If it was a fix, verify the problem is resolved
