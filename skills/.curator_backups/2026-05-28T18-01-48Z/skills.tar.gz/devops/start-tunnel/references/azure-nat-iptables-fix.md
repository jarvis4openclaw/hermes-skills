# Azure NAT iptables DNAT Fix

## Problem

Start Tunnel creates port forward iptables rules that match on destination IP:

```bash
# What Start Tunnel creates:
iptables -t nat -A PREROUTING -d 20.51.120.252 -p tcp --dport 8333 \
  -j DNAT --to-destination 10.59.139.4:56508
```

Azure's SDN rewrites the destination from the public IP to the VM's private IP before the packet reaches the OS. The VM sees:

```
src=64.25.11.235 dst=10.0.0.5 dport=8333
```

The DNAT rule matches `-d 20.51.120.252` — never fires. Packet counter stays at 0.

## Diagnostic Trace

```bash
# 1. Check if packets are matching the DNAT rule:
sudo iptables -t nat -L PREROUTING -n -v
# Look at the first column (pkts) — 0 means NO matches

# 2. Check conntrack to see actual flow:
sudo conntrack -L -d 10.59.139.4
# If this shows entries, forwarding IS working
# If empty, the packet isn't reaching the right chain

# 3. Also check reply direction:
sudo conntrack -L --reply-src 10.59.139.4
# Successful connection looks like:
#   src=<client_ip> dst=10.0.0.5 dport=8333
#     → DNAT →
#   src=<client_ip> dst=10.59.139.4 dport=56508
```

## Workaround

Add an interface-based DNAT rule BEFORE Start Tunnel's chain:

```bash
sudo iptables -t nat -I PREROUTING 1 -i eth0 -p tcp --dport <PUBLIC_PORT> \
  -j DNAT --to-destination <TARGET_IP>:<TARGET_PORT>
```

Example:

```bash
sudo iptables -t nat -I PREROUTING 1 -i eth0 -p tcp --dport 8333 \
  -j DNAT --to-destination 10.59.139.4:56508
```

This matches on the incoming interface (`eth0`) and port, regardless of destination IP.

## Persistence

Start Tunnel rebuilds iptables on every daemon restart, wiping custom rules. Options:

1. **systemd override:** Create `/etc/systemd/system/start-tunneld.service` with `ExecStartPost` that re-adds the rule.
2. **Cron @reboot:** `@reboot sleep 10 && iptables -t nat -I PREROUTING 1 -i eth0 -p tcp --dport 8333 -j DNAT --to-destination 10.59.139.4:56508`
3. **Script:** `/usr/local/bin/st-nat-fix.sh` triggered by systemd or cron.

## Verification

```bash
# Test from an external host:
nc -zv <public_ip> <port>

# Check packet counters (should show >0):
sudo iptables -t nat -L PREROUTING -n -v | head -5

# Check connection tracking:
sudo conntrack -L --reply-src <target_ip>
```

Note: `nc` to a Bitcoin P2P port will timeout because Bitcoin expects a version handshake, not a raw TCP probe. Use conntrack to verify the connection established instead.

## Why This Happens (All Cloud Providers)

| Provider | Behavior |
|----------|----------|
| Azure | Public IP is SDN-level NAT → VM sees private IP |
| AWS | Elastic IP is 1:1 NAT → VM sees private IP (unless assigned to ENI) |
| GCP | External IP is SDN-level NAT → VM sees private IP |
| Hetzner/DigitalOcean | Public IP IS on the interface → DNAT works without workaround |
