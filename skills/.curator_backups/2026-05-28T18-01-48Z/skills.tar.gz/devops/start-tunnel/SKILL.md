---
name: start-tunnel
description: Manage Start9 StartTunnel VPR — SSH access, web UI, subnets, devices, port forwarding, config editing. Use when asked to inspect, troubleshoot, or configure a StartTunnel VPS.
---

# StartTunnel Management

StartTunnel is a Virtual Private Router (VPR) from Start9 — a WireGuard-based VPN that runs on a cheap VPS. Lets you expose home services without revealing your home IP. Separate product from StartOS.

## Boss's Server

| Detail | Value |
|--------|-------|
| Host | `azureuser@20.51.120.252` (Azure VM) |
| OS | Debian 13 (trixie) |
| Version | `start-tunnel 0.4.0-beta.9` |
| Config file | `/var/lib/start-tunnel/tunnel.db` (CBOR binary) |
| Daemon | `/usr/bin/start-tunneld` (no systemd service) |
| RPC | `127.0.59.60:5960/rpc/v0` (JSON-RPC) |
| Docs | https://docs.start9.com/start-tunnel/1.0.x/ |

**Important:** The installed version (0.4.0-beta.9) is older than the docs (1.0.x). CLI flags differ — always check `start-tunnel --help` on the server before assuming docs behavior.

## Web UI

The web UI is bound to localhost by default after `web init`. To access it over WireGuard VPN, it must listen on `0.0.0.0:8080` (or the server's WireGuard IP).

### Changing the listen address

**Preferred method — use Python cbor2 (safe, handles any string length):**

```bash
sudo apt install python3-cbor2

cat > /tmp/fix_listen.py << 'EOF'
import cbor2

with open('/var/lib/start-tunnel/tunnel.db', 'rb') as f:
    raw = f.read()
version = cbor2.loads(raw)
version_bytes = cbor2.dumps(version)
config = cbor2.loads(raw[len(version_bytes):])

config['webserver']['listen'] = '0.0.0.0:8080'

with open('/var/lib/start-tunnel/tunnel.db', 'wb') as f:
    f.write(cbor2.dumps(version))
    f.write(cbor2.dumps(config))
EOF

sudo kill $(pgrep start-tunneld) 2>/dev/null; sleep 1
sudo python3 /tmp/fix_listen.py
sudo /usr/bin/start-tunneld &
```

**Fallback — hex-edit the CBOR config file (only for same-length strings):**

```bash
# 1. Stop the daemon
sudo kill $(pgrep start-tunneld)

# 2. The config is CBOR at /var/lib/start-tunnel/tunnel.db
# Strings have length prefixes: 0x60 + byte_length
# "127.0.0.1:8080" = 14 chars → prefix 0x6E
# "0.0.0.0:8080"    = 12 chars → prefix 0x6C

# 3. Patch the prefix byte after the "listen" field name
# Use Python to find "listen" and fix the adjacent prefix byte:
sudo python3 << 'EOF'
with open("/var/lib/start-tunnel/tunnel.db", "rb") as f:
    data = bytearray(f.read())
idx = data.find(b"listen")
if idx >= 0:
    prefix_pos = idx + 6
    # Change 0x6E (14) to 0x6C (12) for "0.0.0.0:8080"
    data[prefix_pos] = 0x6C
    with open("/var/lib/start-tunnel/tunnel.db", "wb") as f:
        f.write(data)
    print("Patched")
EOF

# 4. Restart the daemon
sudo /usr/bin/start-tunneld &>/dev/null &

# 5. Verify
sudo ss -tlnp | grep start-tunneld
```

### Accessing the web UI

Once bound to `0.0.0.0:8080`:
- **Via WireGuard VPN:** `https://<server-wireguard-ip>:8080`
- **Via SSH tunnel (no config changes needed):** `ssh -L 8080:127.0.0.1:8080 azureuser@20.51.120.252` then `https://localhost:8080`
- **Direct public IP:** requires cloud firewall rule (Azure NSG, etc.) to allow inbound 8080

The web UI redirects HTTP → HTTPS and uses a self-signed cert generated during `web init`.

## Port Forwarding

### Creating a Port Forward

In WebUI → Port Forwarding → Add, or via CLI:

```bash
start-tunnel port-forward add <source_port> <target_ip>:<target_port>
```

**Example — forward Bitcoin P2P to a StartOS host on WireGuard:**

```bash
start-tunnel port-forward add 8333 10.59.139.4:56508
```

Start Tunnel auto-creates iptables DNAT rules. No manual iptables work needed.

### External IP Dropdown Empty?

On cloud providers using NAT (Azure, GCP, AWS), the public IP is NOT bound to the VM — the VM only sees a private IP (e.g., `10.0.0.5`). The UI dropdown reads from interface addresses.

**Fix — add the public IP as a virtual address:**

```bash
# Temporary
sudo ip addr add 20.51.120.252/32 dev eth0

# Restart daemon to pick it up
sudo kill $(pgrep start-tunneld)
sudo /usr/bin/start-tunneld &

# Verify detection
sudo python3 -c "
import cbor2
with open('/var/lib/start-tunnel/tunnel.db','rb') as f:
    raw = f.read()
cfg = cbor2.loads(raw[len(cbor2.dumps(cbor2.loads(raw))):])
print(cfg['gateways']['eth0']['ipInfo']['subnets'])
"
```

**Make permanent (Debian):**
```bash
sudo tee -a /etc/network/interfaces << 'EOF'

auto eth0:0
iface eth0:0 inet static
    address 20.51.120.252
    netmask 255.255.255.255
EOF
```

The daemon auto-detects interface IPs on startup and adds them to `subnets`.

### Azure NAT Caveat (Cloud Providers)

On Azure, AWS, and GCP, the cloud fabric rewrites the public IP to the VM's private IP before the packet hits the OS. Start Tunnel's iptables DNAT rules match on `-d <public_ip>` — these never see the public IP, so port forwards silently fail. Verify with `conntrack -L` or `iptables -t nat -L PREROUTING -v` (check packet counts).

**Workaround:** Add an interface-based DNAT rule. See `references/azure-nat-iptables-fix.md`.

**To test a port forward is working end-to-end:** check `sudo conntrack -L -d <target_ip>`. If you see entries with the original client IP, the forward is live.

### Cloud Firewall

Start Tunnel manages iptables. You still need to open ports in the cloud provider's external firewall:

| Provider | How |
|----------|-----|
| Azure | Network Security Group → Add inbound rule |
| AWS | Security Group → Add inbound rule |
| GCP | VPC Firewall Rules → Add |
| Hetzner/DO/Linode | Usually no cloud firewall needed |
| Oracle | Security List + OS firewall (both required) |

## Subnets & Devices

The config at `/var/lib/start-tunnel/tunnel.db` is CBOR (Concise Binary Object Representation), NOT SQLite despite the `.db` extension.

Structure (human-readable fields embedded in binary):
```
migrations
PortForwardEntry
webserver
  enabled: true
  listen: <ip:port>
  certificate
  key: <PEM>
  cert: <PEM chain>
sessions
authPubkeys
gateways
  eth0: {name, secure, ipInfo, subnets, lanIp, wanIp, ...}
  lo:   {name, secure, ipInfo, subnets, lanIp, wanIp, ...}
  wg:   {port, key, subnets, ...}
subnets
  <cidr>:
    name
    clients
      <ip>: {name, key, psk, ...}
portForwards
```

**CBOR string encoding:** text strings are `0x60 + length`. Binary-safe edits must preserve the prefix byte.

**File-level structure:** The file contains TWO CBOR items in sequence: a version integer (27) followed by the config dictionary. To decode: `cbor2.loads(raw)` → gets version, then `cbor2.loads(raw[len(cbor2.dumps(version)):])` → gets config. To encode back: write both items in order. Single-shot `cbor2.loads()` only sees the version integer.

## Common Commands

| Task | Command |
|------|---------|
| Version | `start-tunnel --version` |
| Web UI listen address | `start-tunnel web get-listen` |
| Set web listen | `start-tunnel web set-listen <ip:port>` (see pitfall above) |
| List subnets | `start-tunnel subnet` ... (check `--help`) |
| Add device | `start-tunnel device add <SUBNET> <NAME> [IP]` |
| Show WireGuard config | `start-tunnel device show-config <SUBNET_CIDR> <DEVICE_IP> [WAN_ADDR]` — always pass WAN_ADDR to avoid bug |
| Port forward | `start-tunnel port-forward add <SOURCE> <TARGET>` |
| Auth / password | `start-tunnel auth set-password` / `reset-password` |
| Update check | `start-tunnel update check` |

## Pitfalls

## References

- `references/show-config-endpoint-bug.md` — Full diagnostic trace of the endpoint generation bug in v0.4.0-beta.9.
- `references/azure-nat-iptables-fix.md` — Why port forwards fail on Azure/AWS/GCP (SDN rewrites destination IP), diagnostic trace, workaround, and persistence options.

- **Version mismatch with docs:** Boss's server runs 0.4.0-beta.9. The docs are for 1.0.x. CLI flags differ. Always run `start-tunnel --help` on the actual server.
- **No systemd service:** The daemon runs as a raw process. After reboot it won't auto-start. Kill via `pgrep`/`pkill`, restart manually. Consider creating a systemd unit for production.
- **CBOR binary config:** The `.db` file is CBOR, not SQLite. Use Python `cbor2` library for safe edits. NEVER use `sed` unless old/new strings are exactly the same byte length.
- **`web set-listen` fails in both states:** Running daemon → "Address in use"; stopped daemon → "error sending request". Edit the config file with the daemon stopped instead.
- **`show-config` endpoint bug (v0.4.0-beta.9):** Endpoint IP defaults to web listen address, not public IP. Setting `wanIp` in the CBOR config does NOT fix it. Workaround: pass `[WAN_ADDR]` explicitly or manually replace Endpoint in generated config.
- **External IP dropdown empty:** Cloud NAT means the public IP isn't on any interface. Add it as a virtual IP (`ip addr add <ip>/32 dev eth0`) and restart the daemon. The daemon auto-detects the IP and adds it to the `subnets` array. Note: the `wanIp` field on the gateway interface object gets overwritten by the daemon on restart — rely on `subnets` detection, not manual `wanIp` edits. Make the virtual IP permanent via `/etc/network/interfaces` or it won't survive reboots.
- **Subnet parameter is CIDR, not name:** CLI commands expect the subnet CIDR (e.g., `10.59.139.1/24`), not the human-readable name. Passing the name fails with "invalid IP address syntax".
- **WireGuard handshake: 0 means never connected:** If `wg show` shows no handshake for a peer, the client hasn't established a tunnel. Check: Endpoint address (not 127.0.0.1/0.0.0.0), client firewall (UDP 51820 outbound), and that the WireGuard client is actually running.
- **Azure's user, not root:** SSH user is `azureuser`. Use `sudo` for privileged commands.
- **Must kill daemon before CBOR edits:** The daemon caches and may overwrite config on shutdown. Always `kill`, edit, then restart.
- **CBOR `key` field is the PRIVATE key:** In `wg.subnets.<cidr>.clients.<ip>.key`, the stored value is the client's WireGuard PRIVATE key, NOT the public key. The daemon derives the public key at runtime. If you overwrite this with a public key, the derivation produces a completely different (wrong) public key — handshakes will fail. To change a peer's key, either use `start-tunnel device add` with a new key, or replace with a valid WireGuard private key.
- **Port forwards get wiped on daemon restart (beta.9):** The iptables rules created by Start Tunnel are rebuilt from scratch when the daemon starts. Any custom iptables rules you add (e.g., the Azure NAT workaround) will be lost — they must be re-applied after each daemon restart.
- **Azure NAT rewrites destination IP:** On Azure VMs (and similar cloud providers), inbound packets to the public IP arrive at the VM with the PRIVATE IP as the destination (10.0.0.5, not 20.51.120.252). Start Tunnel's DNAT rules match on destination IP — so port forwards targeting the public IP NEVER hit. The workaround is to add an interface-based DNAT rule that catches the NAT'd packets: `sudo iptables -t nat -I PREROUTING 1 -i eth0 -p tcp --dport <PUBLIC_PORT> -j DNAT --to-destination <TARGET_IP>:<TARGET_PORT>`. This must be re-applied after any daemon restart. See `references/azure-nat-iptables-fix.md` for full diagnostic trace.
