Below is a **complete, detailed Markdown document** describing the issues you encountered, the root causes, and the fixes we implemented — including the **daily backup cron job** and the **daily prune job**.  
It’s written to be consumed by another AI agent, so it is explicit, structured, and thorough.

---

# **Proxmox VE 9.x Configuration Loss & Recovery — Full Technical Summary**

## **Overview**
This document summarizes the issues encountered on a Proxmox VE 9.1.9 system after a complete loss of the Proxmox configuration database (`pmxcfs`), the steps taken to restore functionality, and the long‑term backup strategy implemented using Proxmox Backup Server (PBS) 4.2.0.

It includes:

- What broke  
- What was restored  
- What could not be restored  
- How configuration backups were implemented  
- The cron jobs created for automated backups and pruning  

This document is intended for ingestion by an AI agent for future troubleshooting or automation.

---

# **1. Initial Problem: pmxcfs Database Wiped**

### **Symptoms**
- `/etc/pve` was empty or partially missing  
- VM and CT configuration files were gone  
- Storage configuration (`storage.cfg`) was missing  
- User and ACL files were missing  
- vzdump backup schedules were missing  
- Proxmox UI showed no VMs or CTs  

### **Cause**
The Proxmox cluster filesystem (`pmxcfs`) stores all node configuration under:

```
/etc/pve
/var/lib/pve-cluster/config.db
```

A corruption or wipe of this database results in total loss of configuration.

---

# **2. Manual Recovery Steps Performed**

## **2.1 Recreated `storage.cfg`**
A new `/etc/pve/storage.cfg` was created manually to restore storage definitions.

## **2.2 Restored VM and CT Configuration Files**
Recovered `.conf` files were placed into:

```
/etc/pve/nodes/<node>/qemu-server/<VMID>.conf
/etc/pve/nodes/<node>/lxc/<CTID>.conf
```

After this, VMs and CTs reappeared in the UI.

## **2.3 Networking Verified**
`/etc/network/interfaces` was intact and required no restoration.

## **2.4 Confirmed No Host Backups or ZFS Snapshots**
- No PBS host backups existed  
- Only a single ZFS snapshot existed for an unrelated dataset  
- No `.pxar` archives containing PVE configs were found  

## **2.5 PBS User/ACL Files Found (Not PVE Files)**
Located:

```
/etc/proxmox-backup/user.cfg
/etc/proxmox-backup/acl.cfg
```

These belong to PBS, not PVE, and cannot restore PVE users or ACLs.

---

# **3. Why PBS Host Backups Could Not Be Used**

### **Reason**
Proxmox VE 9.x does **not yet include** the `pve-host-backup` package required to register a PVE node with PBS for Host Backups.

Therefore, the PBS UI did not show:

```
Administration → Host Backups
```

This feature is available only for PVE 8.x at the time of this incident.

---

# **4. Implemented Solution: PBS File Backups for PVE Configuration**

Since Host Backups are not available on PVE 9.x, we implemented **manual file‑level backups** using `proxmox-backup-client`.

A dedicated PBS namespace was created:

```
Datastore: backups
Namespace: host
```

Then a working backup command was constructed using **pxar archive specs**.

---

# **5. Final Working Backup Command**

This command successfully backs up all critical PVE configuration directories:

```
proxmox-backup-client backup \
  etc-pve.pxar:/etc/pve \
  pve-cluster.pxar:/var/lib/pve-cluster \
  network.pxar:/etc/network \
  firewall.pxar:/etc/pve/firewall \
  priv.pxar:/etc/pve/priv \
  --exclude /var/lib/vz \
  --exclude /mnt/backups \
  --repository root@pam@192.168.100.23:backups \
  --ns host
```

This captures:

- pmxcfs database  
- all PVE configuration files  
- networking  
- firewall rules  
- user/ACL directories  
- vzdump schedules (if present)  

---

# **6. Daily Backup Cron Job**

A cron job was created at:

```
/etc/cron.daily/pve-config-backup
```

Contents:

```
#!/bin/bash

proxmox-backup-client backup \
  etc-pve.pxar:/etc/pve \
  pve-cluster.pxar:/var/lib/pve-cluster \
  network.pxar:/etc/network \
  firewall.pxar:/etc/pve/firewall \
  priv.pxar:/etc/pve/priv \
  --exclude /var/lib/vz \
  --exclude /mnt/backups \
  --repository root@pam@192.168.100.23:backups \
  --ns host
```

Permissions:

```
chmod +x /etc/cron.daily/pve-config-backup
```

This ensures **daily configuration backups** to PBS.

---

# **7. Daily Prune Cron Job (Retention: 14 Days)**

A prune job was created at:

```
/etc/cron.daily/pve-config-prune
```

Contents:

```
#!/bin/bash

proxmox-backup-client prune \
  --repository root@pam@192.168.100.23:backups \
  --ns host \
  --keep-daily 14 \
  --keep-weekly 0 \
  --keep-monthly 0 \
  --keep-yearly 0
```

Permissions:

```
chmod +x /etc/cron.daily/pve-config-prune
```

This ensures the PBS datastore retains **only the last 14 days** of configuration backups.

---

# **8. Current Protection Level**

With the above in place, the system is now protected against:

- pmxcfs corruption  
- accidental deletion of `/etc/pve`  
- loss of VM/CT configuration  
- loss of storage.cfg  
- loss of firewall rules  
- loss of vzdump schedules  
- loss of user/ACL configuration  

Restoration can be performed using:

```
proxmox-backup-client restore <archive> <target-path> --repository ... --ns host
```

---

# **9. Recommended Future Enhancements**

- Enable PBS datastore verification jobs  
- Add email notifications for backup failures  
- Add weekly integrity checks for `/var/lib/pve-cluster`  
- When Proxmox releases `pve-host-backup` for PVE 9.x, migrate to Host Backups  

---
