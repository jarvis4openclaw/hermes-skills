---
name: proxmox-host-management
version: 1.1.0
description: Manage Proxmox VE host via SSH — cron jobs, systemd services, packages, config files, VM/CT operations, storage, network, disk health/SMART monitoring, and maintenance. Use when asked to inspect, fix, or change anything on the Proxmox host itself (not VMs/containers).
category: devops
---

# Proxmox Host Management Skill

## When to Use
Use this skill for any SSH-based management of the Proxmox VE host itself:
- Editing cron jobs, systemd services, config files
- Package updates, kernel management
- VM/CT lifecycle (start/stop/restart/snapshot via `qm`/`pct`)
- Storage pool management, backup scheduling
- Disk health and SMART monitoring (error diagnosis, delta tracking)
- Network config, firewall rules
- Log investigation, troubleshooting
- Maintenance tasks (log rotation, temp cleanup, etc.)

**Do NOT use for:** Read-only resource reports → use `proxmox-resource-reporting` skill instead.

## Access

- **Host:** `root@192.168.100.23` (pve)
- **SSH Key:** `/home/wahid/.ssh/id_ed25519`
- **SSH Command pattern:**
  ```bash
  ssh -i /home/wahid/.ssh/id_ed25519 -o StrictHostKeyChecking=no root@192.168.100.23 '<command>'
  ```
- **Proxmox version:** 9.1.0 (kernel 7.0.2-2-pve)

## Key Config Files

| File | Purpose |
|------|---------|
| `/etc/pve/user.cfg` | Proxmox user config (contains notification email) |

## Reference Files
- `references/ct200-root-disk-shrink.md` — Full shrink operation log (CT 200, 24G→20G)
- `references/host-config-issue.md` — pmxcfs wipe recovery + daily config backup cron setup
- `references/pbs-storage-setup.md` — PBS storage config fix, API token setup, backup ownership pitfall
- `references/api-token-recovery.md` — Recreate api-rw@pam user + token after pmxcfs wipe
- `references/lxc-docker-deploy.md` — Docker Compose service deployment on LXC containers
| `/etc/cron.d/` | System cron jobs (e.g., `azcmagent_autoupgrade`) |
| `/etc/apt/sources.list.d/` | APT sources (Proxmox, Ceph, etc.) |
| `/etc/network/interfaces` | Network configuration |
| `/etc/hostname`, `/etc/hosts` | Hostname and hosts |
| `/etc/postfix/` or `/etc/ssmtp/` | Mail relay config |

## Notification Emails

Proxmox sends emails via **sSMTP relay through Gmail** (`smtp.gmail.com:587`).
Notification email addresses are set in BOTH:
- `/etc/pve/user.cfg`
- `/etc/pve/datacenter.cfg`

Current email: `onewahid@gmail.com` (changed from `onewahid@live.com` on 2026-02-14).

## Common Operations

### VM Management (`qm`)
```bash
# List all VMs
qm list

# Start/stop/restart
qm start <vmid>
qm stop <vmid>
qm restart <vmid>

# Snapshot
qm snapshot <vmid> <snapname> --description "..."

# Get config
qm config <vmid>

# Get status
qm status <vmid>
```

### LXC Container Management (`pct`)
```bash
# List all containers
pct list

# Start/stop/restart
pct start <ctid>
pct stop <ctid>
pct restart <ctid>

# Enter container shell
pct enter <ctid>

# Get config
pct config <ctid>
```

### LXC Container Root Disk Resizing

**Growing** (safe, can be done live on some setups, but stop CT for safety):
```bash
pct stop <ctid>
lvresize -L +<size>G /dev/pve/vm-<ctid>-disk-0
resize2fs /dev/pve/vm-<ctid>-disk-0
pct set <ctid> -rootfs local-lvm:vm-<ctid>-disk-0,size=<new-size>G
pct start <ctid>
```

**Shrinking** (requires CT stop + fs shrink BEFORE volume shrink):
```bash
pct stop <ctid>
e2fsck -fy /dev/pve/vm-<ctid>-disk-0       # MUST pass clean
resize2fs /dev/pve/vm-<ctid>-disk-0 <size>G  # filesystem FIRST
lvreduce -L <size>G /dev/pve/vm-<ctid>-disk-0 # volume SECOND
pct set <ctid> -rootfs local-lvm:vm-<ctid>-disk-0,size=<size>G
pct start <ctid>
pct exec <ctid> -- df -h /                     # verify
```

**Key pitfalls:**
- **Order matters for shrink:** You MUST shrink the filesystem before shrinking the LVM volume. Reversing this destroys data.
- **Stale config metadata:** Proxmox config `rootfs` size field can drift from actual LVM volume size (e.g., config says 4G but volume is 24G). Always check `lvs` and `df` for ground truth. Update with `pct set <ctid> -rootfs local-lvm:vm-<ctid>-disk-0,size=<size>G`.
- **Shrink requires clean fs:** `e2fsck -fy` must succeed before `resize2fs` will shrink. If it fails, do NOT proceed.
- **Enough headroom:** Target size must exceed used space (`df` shows used). Shrinking below used = data loss.

### Storage
```bash
# List storage
pvesm status

# List content of a storage
pvesm content <storage-name>

# Check specific storage details
pvesm path <storage-name>
```

### PBS Backup Storage Configuration

PBS storage in PVE (`/etc/pve/storage.cfg`) is fragile — three things break easily:

**1. Wrong fingerprint** — after pmxcfs wipe or PBS cert change, the fingerprint becomes all zeros. Get real one: `proxmox-backup-manager cert info | grep -i fingerprint`.

**2. Wrong username/realm** — `root@pbs` doesn't exist. Use `root@pam` or an API token like `root@pam!token-name`. `pvesm` needs an API token + password because it uses HTTPS, not the local Unix socket.

**3. Missing credentials** — set via API, not manually: `pvesh set /storage/pbs -password "<token-secret>"`. The file goes to `/etc/pve/priv/storage/pbs.pw`.

#### Full PBS storage fix workflow
```bash
# 1. Get fingerprint
proxmox-backup-manager cert info | grep -i fingerprint

# 2. Generate API token + grant ACL
proxmox-backup-manager user generate-token root@pam pve-backup
proxmox-backup-manager acl update /datastore/backups DatastoreAdmin --auth-id root@pam!pve-backup

# 3. Update storage.cfg
sed -i 's/username root@pam/username root@pam!pve-backup/' /etc/pve/storage.cfg
# Also fix fingerprint in storage.cfg if needed

# 4. Set password — MUST use pvesh, not raw file write
pvesh set /storage/pbs -password "<token-secret>"

# 5. Verify
pvesm list pbs

# 6. Create backup job (daily HH:MM format)
pvesh create /cluster/backup --vmid <vmid> --storage pbs --mode snapshot \
  --schedule "02:00" --compress zstd --enabled 1
```

**Important:** `--schedule "HH:MM"` and `--starttime` are mutually exclusive.

#### Backup ownership pitfall
When switching from `root@pam` to `root@pam!token`, PBS rejects writes with `backup owner check failed`. Old backup groups are owned by `root@pam`; the token can't write to them. **Fix:** delete old snapshots in that VM/CT's group via `proxmox-backup-client forget <snapshot-id>` then re-backup.

See `references/pbs-storage-setup.md` for detailed session notes.

### Systemd Services
```bash
# List all timers
systemctl list-timers --all

# Check a service
systemctl status <service>

# Restart a service
systemctl restart <service>

# Disable a timer
systemctl disable --now <timer>
```

### Cron Jobs
```bash
# List system cron jobs
ls -la /etc/cron.d/

# Edit a cron file (backup first!)
cp /etc/cron.d/<file> /etc/cron.d/<file>.bak
```

### Package Management
```bash
# Update package lists
apt update

# Upgrade (non-interactive)
DEBIAN_FRONTEND=noninteractive apt upgrade -y

# Check for proxmox updates specifically
pveupdate

# Check current version
pveversion -v
```

### Logs
```bash
# Proxmox daemon log
journalctl -u pvedaemon -n 100

# Cluster log
journalctl -u pve-cluster -n 100

# Task log (VM/CT operations)
cat /var/log/pve/tasks/active

# Syslog
tail -100 /var/log/syslog
```

### Network
```bash
# Show interfaces
ip addr show

# Show bridges
brctl show

# Show firewall
iptables -L -n

# Proxmox firewall config
cat /etc/pve/firewall/cluster.fw
```

### Disk Health & SMART Monitoring

When a drive starts throwing SMART errors (smartd alerts, ATA error count increases), diagnose first — don't assume media failure.

#### Diagnosis

```bash
# Full SMART report
smartctl -a /dev/sdX

# Key metrics to check
smartctl -A /dev/sdX | grep -E "Reallocated|Pending|Uncorrectable|UDMA_CRC|Power_On|Temperature"

# Recent error log (shows error type)
smartctl -l error /dev/sdX | head -30

# Short self-test (2 min)
smartctl -t short /dev/sdX
sleep 120
smartctl -l selftest /dev/sdX
```

**Critical distinction:** ICRC/ABRT errors = SATA cable/port signal corruption (cheap fix). Reallocated/Pending/Uncorrectable sectors = media failure (drive replacement needed). Check ALL metrics before recommending action.

#### Delta Monitoring Script

When the error count is stable but rising slowly, set up a daily delta monitor that only alerts on increases:

```bash
cat > /usr/local/bin/smart-monitor-<drive>.sh << 'SCRIPT'
#!/bin/bash
DRIVE="/dev/sdX"
STATE_FILE="/var/lib/smart-monitor/<drive>_error_count.txt"
SERIAL="<serial>"
mkdir -p "$(dirname "$STATE_FILE")"
CURRENT=$(smartctl -l error "$DRIVE" 2>/dev/null | grep -oP 'ATA Error Count:\s*\K[0-9]+' | head -1)
[ -z "$CURRENT" ] && { echo "ERROR: Could not read SMART data"; exit 1; }
PREVIOUS=$(cat "$STATE_FILE" 2>/dev/null || echo "$CURRENT")
echo "$CURRENT" > "$STATE_FILE"
if [ "$CURRENT" -gt "$PREVIOUS" ]; then
    echo "SMART ERROR COUNT INCREASED: $DRIVE (Serial: $SERIAL)"
    echo "Previous: $PREVIOUS | Current: $CURRENT"
    smartctl -A "$DRIVE" | grep -E "Reallocated|Pending|Uncorrectable|UDMA_CRC|Power_On|Temperature"
    exit 1
fi
exit 0
SCRIPT
chmod +x /usr/local/bin/smart-monitor-<drive>.sh
```

Schedule it:
```bash
cat > /etc/cron.d/smart-monitor-<drive> << 'EOF'
# Monitor SMART errors daily at 8am — only emails on increase
MAILTO=onewahid@gmail.com
0 8 * * * root /usr/local/bin/smart-monitor-<drive>.sh
EOF
```

Also check ZFS health since Proxmox uses ZFS pools:
```bash
zpool status -v
zpool list
```

## Known Pitfalls

### 1. Cron Emails
Cron sends **any output** (stdout OR stderr) via email to the job owner.
- `>/dev/null` only redirects **stdout** — stderr still gets emailed
- **Fix:** Use `>/dev/null 2>&1` (redirect stderr too)
- **Cleaner fix:** Add `MAILTO=""` at the top of the cron file to disable email entirely
- **Example:** `/etc/cron.d/azcmagent_autoupgrade` — Azure Arc update checker that was emailing daily

### 2. Azure Arc Agent (`azcmagent`)
- Installed at `/opt/azcmagent/`
- Cron job: `/etc/cron.d/azcmagent_autoupgrade` (daily 1:11 AM)
- Service: `azcmagent.service`
- Token storage: `/var/opt/azcmagent/tokens/`
- Can cause unwanted emails if cron output isn't fully silenced

### 3. Proxmox Config Files
- `/etc/pve/` is a virtual filesystem (pmxcfs) — changes are cluster-aware
- Editing files in `/etc/pve/` directly works but be careful with syntax
- Always backup before editing: `cp file file.bak`

### 4. SSH Escaping
- Complex commands with quotes need careful escaping
- For multi-line or complex edits, use heredoc pattern:
  ```bash
  ssh ... 'cat > /path/to/file << '"'"'EOF'"'"'
  content here
  EOF'
  ```
- Or use `sed -i` for simple replacements

### 5. Package Updates
- Don't run `apt dist-upgrade` on Proxmox without checking release notes
- Use `apt upgrade` for safe updates
- Kernel updates require reboot — schedule maintenance windows
- Check `pveupdate` for Proxmox-specific update info

### 6. Storage Reporting
- LXC container disk usage can show >100% due to bind-mounts inflating the number
- Not always a real issue, but worth verifying if unexpected

### 7. PBS Backup Ownership
- PBS backup groups are owned by the auth-id that created them
- Switching auth (e.g., `root@pam` → `root@pam!token`) causes `backup owner check failed`
- **Fix:** Delete old backup group snapshots (`proxmox-backup-client forget <snapshot-id>`) then re-backup with new auth
- `pvesm` needs API token credentials — CLI `proxmox-backup-client` works via Unix socket but `pvesm` does not

### 8. Stale PBS Locks After Interrupted Backup
When a backup is killed mid-flight (SSH timeout, signal, crash), PBS leaves lock files that block snapshot deletion and future writes to that group:
```bash
# Symptom: "Resource temporarily unavailable" or "unable to acquire snapshot lock"
# Fix: remove stale locks, then delete partial snapshot
rm -f /run/proxmox-backup/locks/backups/<vm|ct>-<vmid>*
proxmox-backup-client forget <group>/<timestamp> --repository root@pam@localhost:backups
```
Lock files are at `/run/proxmox-backup/locks/backups/` — filenames contain the VM/CT ID.

### 9. API Token Loss After pmxcfs Wipe
The pmxcfs database stores `/etc/pve/user.cfg`. After a pmxcfs wipe, all users and API tokens (including `api-rw@pam!moltbot`) are gone. The resource report script and any API-based automation will fail with 401. Recovery: recreate the user, token, and ACLs via SSH. Full procedure in `references/api-token-recovery.md`.

### 10. vzdump Foreground Timeout on Large VMs
SSH-based foreground commands have a 600s timeout. VMs/CTs over ~100GB will be killed mid-backup. Always run large backups in background:
```bash
# DO THIS for backups > 100GB
nohup vzdump <vmid> --storage pbs --mode snapshot --compress zstd \
  > /var/log/vzdump/<name>-manual.log 2>&1 &

# Monitor progress
tail -f /var/log/vzdump/<name>-manual.log
# Or: grep "%" /var/log/vzdump/<name>-manual.log | tail -3
```
CT backups (typically < 20GB) are usually fine in foreground.

### 11. Docker in LXC Requires Nesting
Docker Engine requires kernel features only available when the LXC has `features: nesting=1`. Without it, Docker fails to start or containers crash. Check with `pct config <ctid>` and set via `pct set <ctid> -features nesting=1` (requires CT restart). Once set, Docker uses overlayfs with containerd snapshotter — no extra storage config needed.

For full Docker-on-LXC deployment patterns (install, .env generation, compose build/up, verification), see `references/lxc-docker-deploy.md`.

### 12. SMART Errors ≠ Drive Failure
ICRC/ABRT errors in the SMART error log indicate SATA link-layer corruption — bad cable, loose port, or controller negotiating down (e.g., 6.0 Gb/s → 3.0 Gb/s). These are NOT media failures and don't mean the drive is dying. Only Reallocated_Sector_Ct (>0), Current_Pending_Sector (>0), or Offline_Uncorrectable (>0) indicate actual media damage. Always check all metrics with `smartctl -A /dev/sdX` before concluding a drive needs replacement.

**Example:** May 2026 — 10TB HGST helium at 65k hours with 24 ICRC errors, zero media issues, 100% helium. Drive was healthy; monitoring was set up to track error count delta. Cable swap was the correct fix (not replacement).

**Checklist before recommending drive replacement:**
```bash
smartctl -A /dev/sdX | grep -E "Reallocated_Sector|Current_Pending|Offline_Uncorrectable"
```
All zeros? Drive media is healthy. Non-zero? Investigate replacement.

## Safety Rules

1. **Always backup before editing:** `cp file file.bak`
2. **Test after changes:** Verify the thing you changed actually works
3. **Don't reboot without asking** unless it's an emergency
4. **Don't run `apt dist-upgrade`** without Boss approval
5. **Don't modify `/etc/pve/` files** without understanding the syntax
6. **When in doubt, ask** — especially for network/firewall changes

## Verification Checklist

After making changes:
- [ ] Backup of original file exists
- [ ] Change is syntactically correct
- [ ] Service/timer/cron is in expected state
- [ ] No errors in logs
- [ ] If it was a fix, verify the problem is resolved
