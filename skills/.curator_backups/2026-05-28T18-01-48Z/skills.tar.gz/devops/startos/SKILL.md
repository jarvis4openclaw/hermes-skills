---
name: startos
description: Manage StartOS servers — SSH access, finding service credentials, checking service health, understanding network exposure (mDNS, Tor). Use when asked to inspect, troubleshoot, or configure anything on a StartOS host.
---

# StartOS Management

## SSH Access

StartOS uses key-based SSH. The user is `start9` (root disabled). The `start9` user has `sudo`.

```bash
ssh -i ~/.ssh/id_ed25519 start9@<IP>
```

**Host key changes on version updates** (e.g., beta8 → beta9). Fix with:
```bash
ssh-keygen -f ~/.ssh/known_hosts -R <IP>
ssh-keyscan -H <IP> >> ~/.ssh/known_hosts
```

## Finding Service Credentials

Service data lives under:
```
/media/startos/data/package-data/volumes/<service>/data/main/
```

### Quick Connect URLs & Credentials (stats.yaml)

Every StartOS service exposes a `start9/` subdirectory in its data volume containing:

| File | Purpose |
|------|---------|
| `config.yaml` | User-facing config (translated to native format) |
| `stats.yaml` | Quick Connect URLs, RPC credentials, sync status, disk usage |

**Read stats.yaml to get RPC credentials instantly:**
```bash
sudo cat /media/startos/data/package-data/volumes/<service>/data/main/start9/stats.yaml
```

This file ALWAYS contains (for RPC-enabled services):
- `RPC Username` / `RPC Password` (plaintext, masked in WebUI)
- LAN Quick Connect URL (`.local` mDNS hostname)
- Tor Quick Connect URL (`.onion` address)
- Blockchain sync summary, disk usage, peer counts

### Service Native Config

The service's own config (e.g., `bitcoin.conf`, `lnd.conf`) is in the same parent directory:
```bash
sudo cat /media/startos/data/package-data/volumes/<service>/data/main/bitcoin.conf
```

Use this to see actual bind addresses, ports, whitelist rules, ZMQ endpoints, etc.

## Service Network Exposure

StartOS reverse-proxies ALL service traffic through its `startd` daemon. Services are NOT directly accessible by IP:port. Three access paths:

| Path | Format | Requires |
|------|--------|----------|
| LAN (mDNS) | `<hostname>.local:<port>` | mDNS resolver (macOS/Linux native; Windows: Bonjour) |
| Tor | `<hostname>.onion:<port>` | Tor daemon or Tor Browser |
| Web proxy | `https://<IP>/rpc/<service>/` | Browser/curl with StartOS session cookie |

**Key insight:** Ports shown in `stats.yaml` (e.g., `8332`) are startd proxy forwardings — they won't appear in `ss -tlnp` output. The actual internal bind (e.g., `rpcbind=127.0.0.1:58332` from `bitcoin.conf`) is container-local only.

## Common Commands (0.4.0-beta.x)

| Task | Command |
|------|---------|
| List installed services | `start-cli package list` |
| Server metrics (JSON) | `start-cli server metrics --format json` |
| OS version & hardware | `start-cli server device-info` |
| Service logs | `start-cli package logs <id>` |
| Restart service | `start-cli package restart <id>` |
| Attach to container shell | `start-cli package attach <id>` |
| Server host addresses | `start-cli server host address list` |
| Server host bindings | `start-cli server host binding list` |
| Rebuild service container | `start-cli package rebuild <id>` |
| System restart | `start-cli server restart` |
| Check for updates | `start-cli server update` |

**Note:** `start-cli package info` and `start-cli package config` are NOT valid subcommands in 0.4.0-beta9.

## Checking Listening Ports

StartOS runs many startd proxy ports. Filter for the service you care about:
```bash
sudo ss -tlnp | grep startd
```

Or check the service's own config for internal bind addresses.

## Disk & Resource Checks

```bash
start-cli server metrics --format json
```
Returns CPU%, RAM (total/used/available, including ZRAM), disk (used/available/capacity), temperature.

## Troubleshooting .local Hostname Resolution (0.4.0)

When a `.local` hostname from `stats.yaml` doesn't resolve or returns "connection refused":

1. **Check mDNS status on StartOS:**
   ```bash
   ssh start9@<ip> 'resolvectl status ens18 | grep mDNS'
   # OR: resolvectl mdns
   ```
   If output shows `-mDNS`, mDNS is DISABLED. **Fix:** `sudo resolvectl mdns ens18 yes`

2. **Check avahi registrations:**
   ```bash
   ssh start9@<ip> 'avahi-browse -at 2>/dev/null | head -20'
   ```
   No StartOS service entries = startd isn't announcing services. mDNS enable alone may not fix this.

3. **Check startd DNS (port 53):**
   ```bash
   ssh start9@<ip> 'dig +short +time=2 +tries=1 @127.0.0.1 -p 53 <hostname>.local'
   ```
   Timeout = startd DNS not responding. This is a startd bug in some 0.4.0-beta builds.

4. **Check port bindings:**
   ```bash
   ssh start9@<ip> 'start-cli server host binding list'
   ```
   Empty table = NO bindings configured → no service ports exposed to LAN. The `.local` hostname exists in name only.

5. **Verify the port is actually open:**
   ```bash
   ssh start9@<ip> 'sudo ss -tlnp | grep -E ":8332|:8333"'
   ```
   If nothing shows, the port isn't listening on the host — mDNS alone won't help. A binding must be created in StartOS WebUI or via CLI.

**When .local fails entirely:** Use Tor. Sparrow supports SOCKS5 proxy natively. The `.onion` address from `stats.yaml` works without any LAN configuration.

## Remote Access via VPN Tunnel (Start Tunnel Integration)

When StartOS lives behind NAT and `.local`/Tor are insufficient, a WireGuard tunnel via Start Tunnel provides reliable access without exposing the StartOS IP.

### Setting up WireGuard Client on StartOS

The StartOS device must connect as a WireGuard peer. Generate the config from the Start Tunnel server:

```bash
# On the Start Tunnel server
start-tunnel device show-config <subnet> <startos-ip> [wan-addr]
```

**CRITICAL BUG (v0.4.0-beta.9):** `show-config` copies the web listen IP into the Endpoint field. If listen is `0.0.0.0`, Endpoint becomes `0.0.0.0:51820` (broken). **Always manually replace** with the tunnel server's public IP before pasting into StartOS:

```
Endpoint = 20.51.120.252:51820   # ← replace whatever show-config gives you
```

Install and start WireGuard on StartOS:

```bash
# Create the tunnel config (adjust keys from show-config output)
sudo tee /etc/wireguard/start-tunnel.conf << 'EOF'
[Interface]
Address = 10.59.139.4/24
PrivateKey = <from show-config>

[Peer]
PublicKey = <server pubkey>
PresharedKey = <from show-config>
AllowedIPs = 10.59.139.0/24
Endpoint = <public-ip>:51820
PersistentKeepalive = 25
EOF

sudo wg-quick up start-tunnel
sudo systemctl enable wg-quick@start-tunnel
```

Verify: `wg show` should show `latest handshake: X seconds ago` for the StartOS peer.

### Port Forwarding to StartOS Services

Once the tunnel is up, forward public ports to the StartOS WireGuard IP:

1. In Start Tunnel WebUI: Port Forwarding → Add
2. External IP: the tunnel server's public IP
3. Source Port: the public port you want (e.g., `8333` for Bitcoin P2P)
4. Target: `10.59.139.4:<startos-peer-port>` (the port StartOS assigned, e.g., `56508`)

Start Tunnel handles iptables automatically. You only need to open the port in your cloud provider's NSG (e.g., Azure Network Security Group for inbound TCP/UDP).

### Getting StartOS Service Ports

```bash
ssh start9@<startos-ip> 'start-cli package logs bitcoind | grep -i "p2p\|peer\|listening"'
# OR read the service's native config:
sudo cat /media/startos/data/package-data/volumes/bitcoind/data/main/bitcoin.conf | grep -E "bind|port"
```

The port shown in the StartOS WebUI under Bitcoin Core → Interfaces is the startd-forwarded P2P port — that's your `<startos-peer-port>`.

**Full reference:** `references/start-tunnel-integration.md`

## Pitfalls

- **mDNS may be OFF by default on 0.4.0:** `systemd-resolved` in StartOS 0.4.0-beta may ship with `mDNS=no`. Always check with `resolvectl mdns ens18` before suggesting `.local` hostname connections.
- **mDNS requirement:** `.local` hostnames need mDNS on the CLIENT too. Windows users must install Apple Bonjour (bundled with iTunes, or standalone). macOS/Linux support mDNS natively.
- **Port confusion:** Don't trust `ss -tlnp` to find service ports. Read `stats.yaml` for the LAN-accessible port and `bitcoin.conf` (or equivalent) for the internal bind. But verify the port is actually listening before telling the user to connect.
- **Empty binding list:** `start-cli server host binding list` returning an empty table means NO services are LAN-exposed. This is a config gap, not a connectivity issue.
- **Bitcoin Core password mismatch (0.4.0):** The RPC password shown in StartOS WebUI / `stats.yaml` does NOT always match the `rpcauth` hash in `bitcoin.conf`. If password auth returns `401 Unauthorized` despite correct-looking credentials, the hash is stale. Use **cookie auth** (see `references/bitcoin-core-credentials.md`) or force StartOS to regenerate the hash by toggling the RPC password in WebUI → Bitcoin Core → Settings.
- **Cookie auth is the reliable fallback:** When password auth fails, read `/media/startos/data/package-data/volumes/bitcoind/data/main/.cookie` and use `__cookie__:<hex>` as the Basic Auth username:password. This bypasses the `rpcauth` hash entirely.
- **Sparrow NPE on 401:** If Sparrow throws `Cannot invoke "ErrorMessage.toString()" because "<parameter1>" is null`, it's receiving a `401 Unauthorized` response with an empty JSON-RPC error body. Fix the auth (usually cookie auth) rather than debugging Sparrow.
- **Host key drift:** OS updates regenerate SSH host keys. Keyscan after every version bump.
- **No root SSH:** Only `start9` user. Use `sudo` for privileged commands. `sudo -i` / `sudo su` not needed — just prefix commands.
- **Disk pressure:** The StartOS boot disk is often tight (730GB with blockchain). Monitor with `start-cli server metrics`.
- **Backups:** StartOS backs up via its own mechanism (encrypted, master-password-derived key). Each target overwrites the previous backup. Plan for multiple targets if you need point-in-time recovery.
- **WireGuard tunnel — endpoint IP bug (v0.4.0-beta.9):** When generating client configs via `show-config`, the Endpoint defaults to the web listen IP instead of the WAN IP. Always manually replace the Endpoint address with the tunnel server's public IP in the generated config before pasting it into the client. Passing `[WAN_ADDR]` as an explicit argument also fixes it: `show-config <subnet> <ip> <public-ip>`.
- **WireGuard handshake 0:** If `wg show` reports no handshake for the StartOS peer, ensure (a) `wg-quick@start-tunnel` is enabled/running on the StartOS host, (b) Endpoint is the tunnel server's public IP (not 127.0.0.1 or 0.0.0.0), and (c) UDP 51820 outbound is open on the StartOS network.
- **WireGuard key mismatch:** If `wg show` on the tunnel server shows a handshake but the peer has no `latest handshake` entry or a different public key than expected, run `wg show` on StartOS too and compare public keys. If they differ, StartOS was configured with a different WireGuard keypair than what Start Tunnel generated. Either regenerate from Start Tunnel and apply to StartOS, or update the peer key in Start Tunnel's CBOR config (`wg.subnets.<cidr>.clients.<ip>.key` — note this is the PRIVATE key, the daemon derives the public key). The PSK must also match.
- **AllowedIPs = 0.0.0.0/0 is dangerous on StartOS:** This routes ALL of StartOS's internet traffic through the tunnel server, breaking local services and internet access unless the tunnel server has proper NAT masquerading. Always use `AllowedIPs = 10.59.139.0/24` (or the tunnel subnet) instead. The tunnel is for forwarding, not for StartOS egress.
- **StartOS port forwarding — random peer port:** StartOS assigns a random P2P/peer port via startd (e.g., 56508), not the standard 8333. Find it in the StartOS WebUI under the service's Interfaces tab before setting up port forwards from the tunnel.

## References

- `references/bitcoin-core-credentials.md` — Step-by-step pattern for extracting Bitcoin Core RPC credentials from StartOS and connecting wallets (Sparrow, Specter, etc.). Covers stats.yaml, bitcoin.conf, LAN vs Tor connectivity, and Sparrow-specific wallet configuration.
- `references/start-tunnel-integration.md` — WireGuard client setup on StartOS for Start Tunnel, port forwarding, endpoint IP bug workaround, Azure NSG configuration.
